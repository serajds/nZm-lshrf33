import React, { useState, useCallback, useMemo } from "react";
import { useParams, useLocation } from "wouter";
import { usePageTitle } from "@/hooks/use-page-title";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  useListActivities, 
  useCreateActivity, 
  useUpdateActivity, 
  useDeleteActivity,
  useGetProject,
  getListActivitiesQueryKey,
} from "@workspace/api-client-react";
import { useTabAccess, useMyProjectPermissions } from "@/hooks/use-tab-access";
import type { Activity, ProjectSuspension, UpdateActivityBodyStatus } from "@workspace/api-client-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fmtDate } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ProjectNav } from "@/components/project-nav";
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger 
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

import { 
  Plus, Edit2, Trash2, ArrowRight, ChevronDown, ChevronLeft,
  CheckCircle2, Clock, AlertTriangle, PlayCircle, 
  TrendingUp, TrendingDown, Minus, Timer, ListChecks, CalendarCheck, CalendarX, Hourglass,
  Upload, Download, FileSpreadsheet, GripVertical, FolderPlus, Palette, X, Loader2,
  Search, LayoutList, GanttChart, SlidersHorizontal
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";

function authFetch(url: string, init?: RequestInit) {
  const token = localStorage.getItem("auth_token");
  return fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(init?.headers ?? {}) },
  });
}

interface ActivityGroup {
  id: number;
  projectId: number;
  name: string;
  color: string;
  sortOrder: number;
}

const GROUP_COLORS = [
  { value: "#3b82f6", label: "أزرق" },
  { value: "#10b981", label: "أخضر" },
  { value: "#f59e0b", label: "برتقالي" },
  { value: "#ef4444", label: "أحمر" },
  { value: "#8b5cf6", label: "بنفسجي" },
  { value: "#ec4899", label: "وردي" },
  { value: "#6b7280", label: "رمادي" },
  { value: "#0891b2", label: "سماوي" },
];

const STATUS_OPTIONS = [
  { value: "not_started",  label: "لم يبدأ",      icon: Clock,         cls: "text-muted-foreground" },
  { value: "in_progress",  label: "قيد التنفيذ",   icon: PlayCircle,    cls: "text-blue-500" },
  { value: "completed",    label: "مكتمل",          icon: CheckCircle2,  cls: "text-emerald-600" },
  { value: "delayed",      label: "متأخر",          icon: AlertTriangle, cls: "text-destructive" },
] as const;

const createActivitySchema = (isNoSchedule: boolean) => z.object({
  name: z.string().min(1, "اسم البند مطلوب"),
  plannedStartDate: isNoSchedule ? z.string().optional().default("") : z.string().min(1, "تاريخ البداية المخطط مطلوب"),
  plannedEndDate: isNoSchedule ? z.string().optional().default("") : z.string().min(1, "تاريخ النهاية المخطط مطلوب"),
  actualStartDate: z.string().optional().nullable(),
  actualEndDate: z.string().optional().nullable(),
  actualProgress: z.coerce.number().min(0).max(100),
  weight: z.coerce.number().min(0.01, "الوزن يجب أن يكون أكبر من صفر").max(100, "الوزن لا يتجاوز 100").default(1),
  status: z.enum(["not_started", "in_progress", "completed", "delayed"]).default("not_started"),
  sortOrder: z.coerce.number().default(0),
});

function calcPlannedProgress(a: { plannedStartDate?: string | null; plannedEndDate?: string | null }): number {
  if (!a.plannedStartDate || !a.plannedEndDate) return 0;
  
  const startOfDay = (d: string) => {
    const date = new Date(d);
    date.setHours(0, 0, 0, 0);
    return date.getTime();
  };

  const start = startOfDay(a.plannedStartDate);
  const end = startOfDay(a.plannedEndDate);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const nowTime = now.getTime();
  
  const duration = end - start;
  if (duration <= 0) return nowTime >= end ? 100 : 0;
  
  const elapsed = nowTime - start;
  if (elapsed <= 0) return 0;
  if (elapsed >= duration) return 100;
  return Math.round((elapsed / duration) * 100);
}

const activitySchema = createActivitySchema(false);
type ActivityFormValues = z.infer<typeof activitySchema>;

function StatusBadge({ status }: { status: string }) {
  const s = STATUS_OPTIONS.find(o => o.value === status);
  if (!s) return <Badge variant="outline">{status}</Badge>;
  const Icon = s.icon;
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${s.cls}`}>
      <Icon className="h-3.5 w-3.5 shrink-0" />
      {s.label}
    </span>
  );
}

type DelayInfo =
  | { kind: "delayed";  days: number; label: string }
  | { kind: "early";   days: number; label: string }
  | { kind: "on_time"; days: number; label: string }
  | { kind: "remaining"; days: number; label: string }
  | { kind: "late_start"; days: number; label: string };

function calcActivityDelay(a: Activity): DelayInfo {
  const startOfDay = (value?: string | null) => {
    if (!value) return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return null;
    date.setHours(0, 0, 0, 0);
    return date;
  };
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const plannedEnd = startOfDay(a.plannedEndDate);
  const plannedStart = startOfDay(a.plannedStartDate);
  const diffDays = (aDate: Date, bDate: Date) => Math.round((aDate.getTime() - bDate.getTime()) / 86400000);

  // A completed activity is late when it finished after the planned end.
  // If no actual end was saved, today's date is used as a conservative fallback;
  // this also catches completed activities whose planned end is already past.
  if (a.status === "completed") {
    if (!plannedEnd) return { kind: "on_time", days: 0, label: "—" };
    const refDate = startOfDay(a.actualEndDate) ?? today;
    const d = diffDays(refDate, plannedEnd);
    if (d > 0) return { kind: "delayed", days: d, label: `متأخر ${d} يوم` };
    if (d < 0) return { kind: "early", days: -d, label: `مبكر ${-d} يوم` };
    return { kind: "on_time", days: 0, label: "في الموعد" };
  }

  if (a.status === "not_started") {
    if (!plannedStart) return { kind: "on_time", days: 0, label: "—" };
    const d = diffDays(today, plannedStart);
    if (d > 0) return { kind: "late_start", days: d, label: `تأخر البدء ${d} يوم` };
    return { kind: "remaining", days: -d, label: `${-d} يوم للبدء` };
  }

  // in_progress or explicitly delayed: compare the current day with planned end.
  if (!plannedEnd) return { kind: "on_time", days: 0, label: "—" };
  const d = diffDays(today, plannedEnd);
  if (d > 0) return { kind: "delayed", days: d, label: `متأخر ${d} يوم` };
  if (d === 0) return { kind: "on_time", days: 0, label: "آخر يوم مخطط" };
  return { kind: "remaining", days: -d, label: `${-d} يوم متبقٍ` };
}

function isActivityDelayed(a: Activity): boolean {
  // Keep an explicitly saved delayed status visible even when the schedule is incomplete.
  if (a.status === "delayed") return true;
  const delay = calcActivityDelay(a);
  return delay.kind === "delayed" || delay.kind === "late_start";
}

function DelayBadge({ info }: { info: DelayInfo }) {
  if (info.kind === "delayed" || info.kind === "late_start") {
    const Icon = info.kind === "late_start" ? CalendarX : Timer;
    return (
      <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold bg-red-50 text-red-600 border border-red-200 dark:bg-red-950/40 dark:text-red-400 dark:border-red-800 whitespace-nowrap">
        <Icon className="h-3 w-3 shrink-0" /> {info.label}
      </span>
    );
  }
  if (info.kind === "early") {
    return (
      <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800 whitespace-nowrap">
        <CalendarCheck className="h-3 w-3 shrink-0" /> {info.label}
      </span>
    );
  }
  if (info.kind === "on_time") {
    return (
      <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium bg-blue-50 text-blue-600 border border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800 whitespace-nowrap">
        <CalendarCheck className="h-3 w-3 shrink-0" /> {info.label}
      </span>
    );
  }
  // remaining
  return (
    <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium bg-muted text-muted-foreground border border-border whitespace-nowrap">
      <Hourglass className="h-3 w-3 shrink-0" /> {info.label}
    </span>
  );
}


function ProgressBar({ value, max = 100, color }: { value: number; max?: number; color: string }) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, backgroundColor: color }} />
      </div>
      <span className="text-xs tabular-nums w-8 text-left">{value}%</span>
    </div>
  );
}

function SortableActivityRow({ id, children }: { id: number; children: React.ReactNode }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <SortableRowContext.Provider value={{ dragRef: setActivatorNodeRef, dragListeners: listeners }}>
      <TableRow ref={setNodeRef} style={style} {...attributes}>
        {children}
      </TableRow>
    </SortableRowContext.Provider>
  );
}

const SortableRowContext = React.createContext<{
  dragRef: ((node: HTMLElement | null) => void) | null;
  dragListeners: Record<string, Function> | undefined;
}>({ dragRef: null, dragListeners: undefined });

function DragHandle() {
  const { dragRef, dragListeners } = React.useContext(SortableRowContext);
  return (
    <span
      ref={dragRef as any}
      {...(dragListeners as any)}
      className="cursor-grab active:cursor-grabbing text-muted-foreground/40 hover:text-muted-foreground transition-colors touch-none"
    >
      <GripVertical className="h-4 w-4" />
    </span>
  );
}

function SortableGroupRow({ id, children }: { id: string; children: React.ReactNode }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <SortableRowContext.Provider value={{ dragRef: setActivatorNodeRef, dragListeners: listeners }}>
      <TableRow ref={setNodeRef} style={style} {...attributes} className="bg-muted/50 hover:bg-muted/70 cursor-pointer">
        {children}
      </TableRow>
    </SortableRowContext.Provider>
  );
}

export default function ProjectActivities() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const projectId = parseInt(params.id || "0", 10);
  const { toast } = useToast();
  const { user } = useAuth();
  const isContractorBase = user?.role === "contractor" || user?.isContractorCompanyUser === true;
  const queryClient = useQueryClient();
  usePageTitle("بنود الأعمال");

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [updatingId, setUpdatingId] = useState<number | null>(null);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isGroupDialogOpen, setIsGroupDialogOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupColor, setNewGroupColor] = useState("#3b82f6");
  const [collapsedGroups, setCollapsedGroups] = useState<Set<number | "ungrouped">>(new Set());
  const [viewMode, setViewMode] = useState<"list" | "gantt">("list");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "not_started" | "in_progress" | "completed" | "delayed">("all");
  const [groupFilter, setGroupFilter] = useState<"all" | "ungrouped" | number>("all");

  const { data: project } = useGetProject(projectId, { query: { enabled: !!projectId } });
  const { data: activities, isLoading } = useListActivities(projectId, { query: { enabled: !!projectId } });

  const groupsQueryKey = [`/api/projects/${projectId}/activity-groups`];
  const { data: groups = [] } = useQuery<ActivityGroup[]>({
    queryKey: groupsQueryKey,
    queryFn: async () => {
      const r = await authFetch(`/api/projects/${projectId}/activity-groups`);
      if (!r.ok) return [];
      return r.json();
    },
    enabled: !!projectId,
  });

  const { data: myPermissions } = useMyProjectPermissions(projectId);
  const { canEdit: canEditActivities, isHidden } = useTabAccess(projectId, "activities", { redirectIfHidden: true });
  const canEditAll = canEditActivities && (myPermissions?.canEditAll ?? true);
  const assignedGroupIds = myPermissions?.assignedGroupIds ?? [];
  const isViewer = !canEditActivities;
  const canEditActivity = useCallback((a: Activity) => {
    if (isViewer) return false;
    if (canEditAll) return true;
    if (assignedGroupIds.length === 0) return true;
    return a.groupId != null && assignedGroupIds.includes(a.groupId);
  }, [canEditAll, assignedGroupIds, isViewer]);

  const createGroup = useMutation({
    mutationFn: async (data: { name: string; color: string }) => {
      const r = await authFetch(`/api/projects/${projectId}/activity-groups`, {
        method: "POST",
        body: JSON.stringify(data),
      });
      if (!r.ok) throw new Error("فشل إنشاء المجموعة");
      return r.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: groupsQueryKey });
      setIsGroupDialogOpen(false);
      setNewGroupName("");
      setNewGroupColor("#3b82f6");
      toast({ title: "تم إنشاء المجموعة" });
    },
  });

  const deleteGroup = useMutation({
    mutationFn: async (id: number) => {
      const r = await authFetch(`/api/projects/${projectId}/activity-groups/${id}`, { method: "DELETE" });
      if (!r.ok) throw new Error("فشل حذف المجموعة");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: groupsQueryKey });
      invalidate();
      toast({ title: "تم حذف المجموعة" });
    },
  });

  const reorderActivities = useMutation({
    mutationFn: async (items: { id: number; sortOrder: number; groupId: number | null }[]) => {
      const r = await authFetch(`/api/projects/${projectId}/activities/reorder`, {
        method: "PUT",
        body: JSON.stringify({ items }),
      });
      if (!r.ok) throw new Error("فشل إعادة الترتيب");
      return r.json();
    },
    onSuccess: () => invalidate(),
  });

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const toggleGroupCollapse = (gid: number | "ungrouped") => {
    setCollapsedGroups(prev => {
      const next = new Set(prev);
      if (next.has(gid)) next.delete(gid);
      else next.add(gid);
      return next;
    });
  };

  const assignToGroup = async (activityId: number, groupId: number | null) => {
    setUpdatingId(activityId);
    try {
      await authFetch(`/api/projects/${projectId}/activities/${activityId}`, {
        method: "PATCH",
        body: JSON.stringify({ groupId }),
      });
      invalidate();
    } catch {
      toast({ variant: "destructive", title: "فشل نقل البند" });
    } finally {
      setUpdatingId(null);
    }
  };

  const reorderGroupsMutation = useMutation({
    mutationFn: async (order: number[]) => {
      const r = await authFetch(`/api/projects/${projectId}/activity-groups/reorder`, {
        method: "PUT",
        body: JSON.stringify({ order }),
      });
      if (!r.ok) throw new Error("فشل إعادة ترتيب المجموعات");
      return r.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: groupsQueryKey }),
  });

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const activeStr = String(active.id);
    const overStr = String(over.id);

    if (activeStr.startsWith("group-") && overStr.startsWith("group-")) {
      const activeGid = parseInt(activeStr.replace("group-", ""), 10);
      const overGid = parseInt(overStr.replace("group-", ""), 10);
      const sorted = [...groups].sort((a, b) => a.sortOrder - b.sortOrder);
      const oldIdx = sorted.findIndex(g => g.id === activeGid);
      const newIdx = sorted.findIndex(g => g.id === overGid);
      if (oldIdx === -1 || newIdx === -1) return;
      const reordered = arrayMove(sorted, oldIdx, newIdx);
      reorderGroupsMutation.mutate(reordered.map(g => g.id));
      return;
    }

    if (!activities) return;
    const oldIndex = activities.findIndex(a => a.id === active.id);
    const newIndex = activities.findIndex(a => a.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;

    const reordered = arrayMove([...activities], oldIndex, newIndex);
    const items = reordered.map((a, i) => ({
      id: a.id,
      sortOrder: i,
      groupId: (a as any).groupId ?? null,
    }));
    reorderActivities.mutate(items);
  };
  const { data: suspensions = [] } = useQuery<ProjectSuspension[]>({
    queryKey: [`/api/projects/${projectId}/suspensions`],
    queryFn: async () => {
      const r = await authFetch(`/api/projects/${projectId}/suspensions`);
      if (!r.ok) return [];
      return r.json();
    },
    enabled: !!projectId,
  });
  
  const createActivity = useCreateActivity();
  const updateActivity = useUpdateActivity();
  const deleteActivity = useDeleteActivity();

  const isNoSchedule = project?.noSchedule === true;
  const currentSchema = useMemo(() => createActivitySchema(isNoSchedule), [isNoSchedule]);

  const form = useForm<ActivityFormValues>({
    resolver: zodResolver(currentSchema),
    defaultValues: {
      name: "", plannedStartDate: "", plannedEndDate: "",
      actualStartDate: "", actualEndDate: "",
      actualProgress: 0,
      weight: 1,
      status: "not_started", sortOrder: 0,
    }
  });

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: getListActivitiesQueryKey(projectId) });

  const exportActivities = async () => {
    if (!activities || activities.length === 0) {
      toast({ variant: "destructive", title: "لا توجد بنود للتصدير" });
      return;
    }
    const XLSX = await import("xlsx");
    const statusLabels: Record<string, string> = { not_started: "لم يبدأ", in_progress: "قيد التنفيذ", completed: "مكتمل", delayed: "متأخر" };
    const data = [
      ["اسم البند", "تاريخ البداية المخططة", "تاريخ النهاية المخططة", "البداية الفعلية", "النهاية الفعلية", "الإنجاز المخطط %", "الإنجاز الفعلي %", "الحالة"],
      ...activities.map((a: any) => [
        a.name,
        a.plannedStartDate?.split("T")[0] || "",
        a.plannedEndDate?.split("T")[0] || "",
        a.actualStartDate?.split("T")[0] || "",
        a.actualEndDate?.split("T")[0] || "",
        calcPlannedProgress(a),
        a.actualProgress ?? 0,
        statusLabels[a.status] || a.status,
      ]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    ws["!cols"] = [{ wch: 30 }, { wch: 16 }, { wch: 16 }, { wch: 16 }, { wch: 16 }, { wch: 14 }, { wch: 14 }, { wch: 14 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "بنود الأعمال");
    const projectName = project?.name || "مشروع";
    XLSX.writeFile(wb, `بنود_${projectName}.xlsx`);
  };

  const downloadTemplate = async () => {
    const XLSX = await import("xlsx");
    const wb = XLSX.utils.book_new();
    const data = [
      ["اسم البند", "تاريخ البداية", "تاريخ النهاية"],
      ["أعمال الحفر والترابية", "2025-01-15", "2025-03-15"],
      ["أعمال الأساسات", "2025-03-01", "2025-05-30"],
      ["أعمال الهيكل الخرساني", "2025-05-15", "2025-09-30"],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    ws["!cols"] = [{ wch: 30 }, { wch: 16 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, ws, "بنود الأعمال");
    XLSX.writeFile(wb, "قالب_بنود_الأعمال.xlsx");
  };

  const handleImport = async () => {
    if (!importFile) return;
    setIsImporting(true);
    try {
      const formData = new FormData();
      formData.append("file", importFile);
      const token = localStorage.getItem("auth_token");
      const res = await fetch(`/api/projects/${projectId}/activities/import`, {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      });
      const result = await res.json();
      if (!res.ok) {
        const errorMsg = result.errors?.length
          ? result.errors.join("\n")
          : result.error || "فشل الاستيراد";
        toast({ variant: "destructive", title: "خطأ في الاستيراد", description: errorMsg });
        return;
      }
      invalidate();
      setIsImportOpen(false);
      setImportFile(null);
      const msg = result.errors?.length
        ? `تم استيراد ${result.imported} بند مع ${result.errors.length} تحذير`
        : `تم استيراد ${result.imported} بند بنجاح`;
      toast({ title: msg });
    } catch {
      toast({ variant: "destructive", title: "فشل الاستيراد" });
    } finally {
      setIsImporting(false);
    }
  };

  const handleEdit = (a: Activity) => {
    setEditingId(a.id);
    form.reset({
      name: a.name,
      plannedStartDate: a.plannedStartDate ? new Date(a.plannedStartDate).toISOString().split('T')[0] : "",
      plannedEndDate: a.plannedEndDate ? new Date(a.plannedEndDate).toISOString().split('T')[0] : "",
      actualStartDate: a.actualStartDate ? new Date(a.actualStartDate).toISOString().split('T')[0] : "",
      actualEndDate: a.actualEndDate ? new Date(a.actualEndDate).toISOString().split('T')[0] : "",
      actualProgress: a.actualProgress,
      weight: a.weight ?? 1,
      status: a.status as ActivityFormValues["status"],
      sortOrder: a.sortOrder ?? 0,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    try {
      await deleteActivity.mutateAsync({ projectId, id: deletingId });
      invalidate();
      toast({ title: "تم حذف البند" });
    } catch {
      toast({ variant: "destructive", title: "فشل الحذف" });
    } finally {
      setDeletingId(null);
    }
  };

  /* ── Quick status update ── */
  const quickUpdateStatus = async (a: Activity, newStatus: string) => {
    if (a.status === newStatus) return;
    setUpdatingId(a.id);
    try {
      const extra: Record<string, unknown> = {};
      if (newStatus === "completed") extra.actualProgress = 100;
      if (newStatus === "not_started") extra.actualProgress = 0;
      await updateActivity.mutateAsync({ projectId, id: a.id, data: { status: newStatus as UpdateActivityBodyStatus, ...extra } });
      invalidate();
      toast({ title: "تم تحديث الحالة" });
    } catch {
      toast({ variant: "destructive", title: "فشل التحديث" });
    } finally {
      setUpdatingId(null);
    }
  };

  /* ── Quick progress increment ── */
  const quickIncrement = async (a: Activity, delta: number) => {
    const next = Math.min(100, Math.max(0, a.actualProgress + delta));
    if (next === a.actualProgress) return;
    setUpdatingId(a.id);
    try {
      const autoStatus = next === 100 ? "completed" : next === 0 ? "not_started" : "in_progress";
      await updateActivity.mutateAsync({
        projectId, id: a.id,
        data: { actualProgress: next, status: autoStatus }
      });
      invalidate();
    } catch {
      toast({ variant: "destructive", title: "فشل التحديث" });
    } finally {
      setUpdatingId(null);
    }
  };

  const onSubmit = async (values: ActivityFormValues) => {
    try {
      const payload = {
        ...values,
        actualStartDate: values.actualStartDate || null,
        actualEndDate: values.actualEndDate || null,
      };
      if (editingId) {
        await updateActivity.mutateAsync({ projectId, id: editingId, data: payload });
        toast({ title: "تم التحديث" });
      } else {
        await createActivity.mutateAsync({ projectId, data: payload });
        toast({ title: "تمت الإضافة" });
      }
      invalidate();
      setIsDialogOpen(false);
      form.reset();
      setEditingId(null);
    } catch {
      toast({ variant: "destructive", title: "فشل الحفظ" });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'not_started': return <Badge variant="outline">لم يبدأ</Badge>;
      case 'in_progress': return <Badge className="bg-blue-500 text-white">قيد التنفيذ</Badge>;
      case 'completed': return <Badge className="bg-emerald-500 text-white">مكتمل</Badge>;
      case 'delayed': return <Badge variant="destructive">متأخر</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const allActivityRows = activities ?? [];
  const filteredActivities = useMemo(() => {
    const query = searchQuery.trim().toLocaleLowerCase();

    return allActivityRows.filter((activity) => {
      const matchesSearch = !query || activity.name.toLocaleLowerCase().includes(query);
      const matchesStatus = statusFilter === "all"
        ? true
        : statusFilter === "delayed"
          ? isActivityDelayed(activity)
          : activity.status === statusFilter;
      const activityGroupId = (activity as Activity & { groupId?: number | null }).groupId ?? null;
      const matchesGroup = groupFilter === "all"
        ? true
        : groupFilter === "ungrouped"
          ? activityGroupId === null
          : activityGroupId === groupFilter;
      return matchesSearch && matchesStatus && matchesGroup;
    });
  }, [allActivityRows, groupFilter, searchQuery, statusFilter]);

  const activityRows = filteredActivities;
  const hasActiveFilters = Boolean(searchQuery.trim()) || statusFilter !== "all" || groupFilter !== "all";
  const effectiveViewMode = isContractorBase ? "gantt" : viewMode;
  const ganttData = activityRows.map((a) => ({
    name: a.name.length > 14 ? a.name.slice(0, 14) + "…" : a.name,
    "المخطط": calcPlannedProgress(a),
    "الفعلي": a.actualProgress,
  }));

  const allDates = activityRows.flatMap(a => [
    a.plannedStartDate, a.plannedEndDate, a.actualStartDate, a.actualEndDate
  ].filter(Boolean) as string[]);
  const ganttStart = allDates.length > 0
    ? new Date(Math.min(...allDates.map(d => new Date(d).getTime())))
    : new Date(project?.startDate ?? Date.now());
  const ganttEnd = allDates.length > 0
    ? new Date(Math.max(...allDates.map(d => new Date(d).getTime())))
    : new Date(project?.expectedEndDate ?? Date.now());

  const completedCount = allActivityRows.filter(a => a.status === "completed").length;
  const inProgressCount = allActivityRows.filter(a => a.status === "in_progress").length;
  const delayedCount = allActivityRows.filter(isActivityDelayed).length;
  const statusCounts = useMemo(() => ({
    all: allActivityRows.length,
    not_started: allActivityRows.filter(a => a.status === "not_started").length,
    in_progress: inProgressCount,
    completed: completedCount,
    delayed: delayedCount,
  }), [allActivityRows, completedCount, delayedCount, inProgressCount]);
  const groupCounts = useMemo(() => {
    const counts = new Map<number, number>();
    let ungrouped = 0;
    for (const activity of allActivityRows) {
      const groupId = (activity as Activity & { groupId?: number | null }).groupId;
      if (groupId == null) ungrouped += 1;
      else counts.set(groupId, (counts.get(groupId) ?? 0) + 1);
    }
    return { counts, ungrouped };
  }, [allActivityRows]);
  const totalWeight = allActivityRows.reduce((sum, a) => sum + (a.weight && a.weight > 0 ? a.weight : 1), 0);
  const actualProgress = totalWeight > 0
    ? Math.round((allActivityRows.reduce((sum, a) => sum + (a.actualProgress ?? 0) * (a.weight && a.weight > 0 ? a.weight : 1), 0) / totalWeight) * 10) / 10
    : 0;
  const plannedProgress = allActivityRows.length > 0
    ? Math.round((allActivityRows.reduce((sum, a) => sum + calcPlannedProgress(a), 0) / allActivityRows.length) * 10) / 10
    : 0;
  const progressDelta = Math.round((actualProgress - plannedProgress) * 10) / 10;

  return (
    <div className="mx-auto max-w-[1600px] space-y-6">
      <div className="page-hero flex flex-wrap items-start gap-3">
        <Button variant="ghost" size="icon" className="relative z-10 mt-0.5 shrink-0 text-white/80 hover:bg-white/10 hover:text-white" onClick={() => setLocation("/projects")}>
          <ArrowRight className="h-5 w-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="relative z-10 text-lg font-bold leading-tight text-white md:text-2xl">{project?.name}</h1>
          <p className="relative z-10 mt-1 text-sm text-white/65">الجدول الزمني</p>
        </div>
      </div>

      <ProjectNav projectId={projectId} />

      <section aria-labelledby="activities-overview" className="space-y-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">نظرة تشغيلية</p>
            <h2 id="activities-overview" className="mt-1 text-xl font-bold tracking-tight">متابعة تقدم بنود الأعمال</h2>
            <p className="mt-1 text-sm text-muted-foreground">ملخص سريع للحالة الحالية قبل مراجعة المخطط الزمني والتفاصيل.</p>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            {isLoading ? "جاري تحديث البيانات" : hasActiveFilters ? `عرض ${activityRows.length} من ${allActivityRows.length} بند` : `آخر عرض · ${allActivityRows.length} بند`}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
          {[
            { label: "إجمالي البنود", value: allActivityRows.length, note: `${groups.length} مجموعة`, icon: ListChecks, tone: "text-primary", dot: "bg-primary" },
            { label: "نسبة الإنجاز", value: `${actualProgress}%`, note: progressDelta >= 0 ? `+${progressDelta}% عن المخطط` : `${progressDelta}% عن المخطط`, icon: TrendingUp, tone: progressDelta < 0 ? "text-destructive" : "text-emerald-600", dot: progressDelta < 0 ? "bg-destructive" : "bg-emerald-500" },
            { label: "مكتمل", value: completedCount, note: allActivityRows.length ? `${Math.round((completedCount / allActivityRows.length) * 100)}% من البنود` : "لا توجد بيانات", icon: CheckCircle2, tone: "text-emerald-600", dot: "bg-emerald-500" },
            { label: "قيد التنفيذ", value: inProgressCount, note: "تحتاج متابعة دورية", icon: Timer, tone: "text-blue-600", dot: "bg-blue-500" },
            { label: "متأخر", value: delayedCount, note: delayedCount > 0 ? "تحتاج إجراءً تصحيحياً" : "لا توجد حالات متأخرة", icon: AlertTriangle, tone: delayedCount > 0 ? "text-destructive" : "text-muted-foreground", dot: delayedCount > 0 ? "bg-destructive" : "bg-muted-foreground" },
          ].map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.label} className="surface-card surface-card-hover overflow-hidden">
                <CardContent className="relative p-4 sm:p-5">
                  <div className={`mb-4 flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-muted/40 ${stat.tone}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-medium text-muted-foreground">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold tracking-tight tabular-nums">{stat.value}</p>
                  <p className="mt-1 truncate text-[11px] text-muted-foreground">{stat.note}</p>
                  <span className={`absolute left-0 top-0 h-1 w-full ${stat.dot}`} />
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      <Card className="surface-card surface-card-hover" dir="rtl">
        <CardContent className="p-4 sm:p-5">
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-border bg-muted/40 text-primary">
                  <SlidersHorizontal className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-semibold">مساحة العمل</p>
                  <p className="text-xs text-muted-foreground">ابحث وفلتر البنود ثم اختر طريقة العرض المناسبة للمراجعة.</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="tabular-nums">عرض {activityRows.length} من {allActivityRows.length}</span>
                {hasActiveFilters && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-xs text-primary"
                    onClick={() => { setSearchQuery(""); setStatusFilter("all"); setGroupFilter("all"); }}
                  >
                    مسح الفلاتر
                  </Button>
                )}
              </div>
            </div>

            <div className="grid gap-5 xl:grid-cols-[minmax(260px,0.85fr)_minmax(0,2.15fr)]">
              <div className="flex flex-col gap-3">
                <div className="relative">
                  <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={searchQuery}
                    onChange={(event) => setSearchQuery(event.target.value)}
                    placeholder="ابحث باسم البند..."
                    aria-label="البحث في بنود الأعمال"
                    className="h-10 bg-background pr-9"
                  />
                </div>
                <div className="flex items-center gap-1 rounded-lg border border-border bg-muted/30 p-1">
                  <Button
                    type="button"
                    size="sm"
                    variant={effectiveViewMode === "list" ? "default" : "ghost"}
                    className="h-8 flex-1 gap-1.5 px-3 text-xs sm:flex-none"
                    disabled={isContractorBase}
                    onClick={() => setViewMode("list")}
                    title={isContractorBase ? "عرض القائمة غير متاح لهذا الدور" : "عرض القائمة"}
                  >
                    <LayoutList className="h-4 w-4" /> القائمة
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={effectiveViewMode === "gantt" ? "default" : "ghost"}
                    className="h-8 flex-1 gap-1.5 px-3 text-xs sm:flex-none"
                    onClick={() => setViewMode("gantt")}
                  >
                    <GanttChart className="h-4 w-4" /> جانت
                  </Button>
                </div>
              </div>

              <div className="min-w-0 space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-muted-foreground">فهرس الحالة</span>
                    <span className="text-[11px] text-muted-foreground">اختيار مباشر</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 2xl:grid-cols-6" role="group" aria-label="فهرس حالات بنود الأعمال">
                    <Button
                      type="button"
                      size="sm"
                      variant={statusFilter === "all" ? "default" : "outline"}
                      aria-pressed={statusFilter === "all"}
                      className="h-9 min-w-0 justify-center gap-1.5 px-2 text-xs"
                      onClick={() => setStatusFilter("all")}
                    >
                      <ListChecks className="h-3.5 w-3.5" />
                      كل الحالات
                      <span className="rounded-full bg-black/10 px-1.5 py-0.5 text-[10px] tabular-nums dark:bg-white/15">{statusCounts.all}</span>
                    </Button>
                    {STATUS_OPTIONS.map((option) => {
                      const Icon = option.icon;
                      const isSelected = statusFilter === option.value;
                      return (
                        <Button
                          key={option.value}
                          type="button"
                          size="sm"
                          variant={isSelected ? "default" : "outline"}
                          aria-pressed={isSelected}
                          className={`h-9 min-w-0 justify-center gap-1.5 px-2 text-xs ${isSelected ? "" : option.cls}`}
                          onClick={() => setStatusFilter(option.value)}
                        >
                          <Icon className="h-3.5 w-3.5" />
                          {option.label}
                          <span className="rounded-full bg-black/10 px-1.5 py-0.5 text-[10px] tabular-nums dark:bg-white/15">{statusCounts[option.value]}</span>
                        </Button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-muted-foreground">فهرس المجموعات</span>
                    <span className="text-[11px] text-muted-foreground">{groups.length} مجموعات</span>
                  </div>
                  <div className="flex flex-wrap gap-2" role="group" aria-label="فهرس مجموعات بنود الأعمال">
                    <Button
                      type="button"
                      size="sm"
                      variant={groupFilter === "all" ? "default" : "outline"}
                      aria-pressed={groupFilter === "all"}
                      className="h-9 min-w-0 justify-center gap-1.5 px-2 text-xs"
                      onClick={() => setGroupFilter("all")}
                    >
                      كل المجموعات
                      <span className="rounded-full bg-black/10 px-1.5 py-0.5 text-[10px] tabular-nums dark:bg-white/15">{allActivityRows.length}</span>
                    </Button>
                    {groups.slice().sort((a, b) => a.sortOrder - b.sortOrder).map((group) => {
                      const isSelected = groupFilter === group.id;
                      return (
                        <Button
                          key={group.id}
                          type="button"
                          size="sm"
                          variant={isSelected ? "default" : "outline"}
                          aria-pressed={isSelected}
                          className="h-9 min-w-0 justify-center gap-1.5 px-2 text-xs"
                          onClick={() => setGroupFilter(group.id)}
                        >
                          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: group.color }} />
                          <span className="max-w-[12rem] truncate">{group.name}</span>
                          <span className="rounded-full bg-black/10 px-1.5 py-0.5 text-[10px] tabular-nums dark:bg-white/15">{groupCounts.counts.get(group.id) ?? 0}</span>
                        </Button>
                      );
                    })}
                    {groupCounts.ungrouped > 0 && (
                      <Button
                        type="button"
                        size="sm"
                        variant={groupFilter === "ungrouped" ? "default" : "outline"}
                        aria-pressed={groupFilter === "ungrouped"}
                        className="h-9 min-w-0 justify-center gap-1.5 px-2 text-xs"
                        onClick={() => setGroupFilter("ungrouped")}
                      >
                        بدون مجموعة
                        <span className="rounded-full bg-black/10 px-1.5 py-0.5 text-[10px] tabular-nums dark:bg-white/15">{groupCounts.ungrouped}</span>
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6">
        {/* ── Gantt Chart ── */}
        {effectiveViewMode === "gantt" && activityRows.length > 0 && (() => {
          const today = new Date(); today.setHours(0, 0, 0, 0);
          const spanMs = ganttEnd.getTime() - ganttStart.getTime() || 86400000;
          const toPct = (d: Date) => Math.max(0, Math.min(100, (d.getTime() - ganttStart.getTime()) / spanMs * 100));
          const todayPct = toPct(today);
          const NAME_W = 176; // px — fixed name column

          const ticks = [0, 25, 50, 75, 100].map(p => ({
            pct: p,
            label: fmtDate(new Date(ganttStart.getTime() + p / 100 * spanMs).toISOString().split("T")[0]),
          }));

          const suspLabel = (t: string) =>
            t === "official_holiday" ? "عطلة رسمية" : t === "force_majeure" ? "ظرف قاهر" : "توقف مقاول";

          return (
            <Card className="surface-card surface-card-hover">
              <CardHeader className="pb-3">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <CardTitle className="text-base">مخطط Gantt - الجدول الزمني</CardTitle>
                  {/* Legend */}
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-6 h-3 rounded-sm bg-blue-400/70" /> مخطط
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-6 h-3 rounded-sm bg-emerald-500" /> فعلي / مكتمل
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-6 h-3 rounded-sm bg-red-500" /> فعلي / متأخر
                    </span>
                    {suspensions.some(s => s.type === "official_holiday") && (
                      <span className="flex items-center gap-1.5">
                        <span className="inline-block w-4 h-3 rounded-sm" style={{ background: "rgba(139,92,246,0.35)", border: "1px solid rgba(139,92,246,0.6)" }} /> عطلة رسمية
                      </span>
                    )}
                    {suspensions.some(s => s.type === "force_majeure") && (
                      <span className="flex items-center gap-1.5">
                        <span className="inline-block w-4 h-3 rounded-sm" style={{ background: "rgba(239,68,68,0.25)", border: "1px solid rgba(239,68,68,0.5)" }} /> ظرف قاهر
                      </span>
                    )}
                    {suspensions.some(s => s.type === "contractor_delay") && (
                      <span className="flex items-center gap-1.5">
                        <span className="inline-block w-4 h-3 rounded-sm" style={{ background: "rgba(249,115,22,0.25)", border: "1px solid rgba(249,115,22,0.5)" }} /> توقف مقاول
                      </span>
                    )}
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-px h-3 bg-red-500" style={{ borderLeft: "2px dashed #ef4444" }} /> اليوم
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block h-3 rounded-sm bg-emerald-500" style={{ width: 3 }} /> بدأ بدون نسبة
                    </span>
                    <span className="flex items-center gap-1.5 text-amber-600">
                      <AlertTriangle className="w-3 h-3" /> تواريخ ناقصة
                    </span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <div className="overflow-x-auto">
                  <div style={{ minWidth: 640 }}>

                    {/* ── Date tick header ── */}
                    <div className="flex items-end border-b border-border pb-1 mb-0" style={{ paddingRight: NAME_W }}>
                      <div className="flex-1 relative h-6">
                        {ticks.map(({ pct, label }) => (
                          <span
                            key={pct}
                            className="absolute bottom-0 text-[10px] font-mono text-muted-foreground"
                            style={{
                              right: `${pct}%`,
                              transform: pct === 0 ? "none" : pct === 100 ? "translateX(100%)" : "translateX(50%)",
                              whiteSpace: "nowrap",
                            }}
                          >
                            {label}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* ── Activity rows ── */}
                    {activityRows.map((a, idx) => {
                      const barColor = a.status === "delayed" ? "#ef4444" : a.status === "completed" ? "#10b981" : "#10b981";
                      const actualEnd = a.actualEndDate ?? (a.actualStartDate ? today.toISOString().split("T")[0] : null);
                      const isLast = idx === activityRows.length - 1;

                      return (
                        <div
                          key={a.id}
                          className={`flex items-stretch ${!isLast ? "border-b border-border/50" : ""}`}
                          style={{ minHeight: 54 }}
                        >
                          {/* Name column */}
                          <div
                            className="shrink-0 flex items-center gap-2 py-2 pr-1 border-l border-border/40"
                            style={{ width: NAME_W, minWidth: NAME_W }}
                          >
                            <StatusBadge status={a.status} />
                            <span
                              className="text-xs font-medium text-foreground leading-tight line-clamp-2"
                              style={{ maxWidth: NAME_W - 56 }}
                              title={a.name}
                            >
                              {a.name}
                            </span>
                          </div>

                          {/* Timeline column */}
                          <div className="flex-1 relative py-2">

                            {/* Grid lines */}
                            {[25, 50, 75].map(p => (
                              <div key={p} className="absolute inset-y-0 w-px bg-border/50" style={{ right: `${p}%` }} />
                            ))}

                            {/* Today marker */}
                            {todayPct > 0 && todayPct < 100 && (
                              <div
                                className="absolute inset-y-0 w-px z-20 pointer-events-none"
                                style={{ right: `${todayPct}%`, borderRight: "2px dashed #ef4444", opacity: 0.75 }}
                                title={`اليوم: ${fmtDate(today.toISOString().split("T")[0])}`}
                              />
                            )}

                            {/* Suspension overlays */}
                            {suspensions.map(susp => {
                              const sl = toPct(new Date(susp.startDate));
                              const er = toPct(new Date(susp.endDate));
                              const sw = Math.max(0.4, er - sl);
                              const bg = susp.type === "official_holiday"
                                ? "rgba(139,92,246,0.14)"
                                : susp.type === "force_majeure"
                                  ? "rgba(239,68,68,0.12)"
                                  : "rgba(249,115,22,0.12)";
                              const bd = susp.type === "official_holiday"
                                ? "1px solid rgba(139,92,246,0.45)"
                                : susp.type === "force_majeure"
                                  ? "1px solid rgba(239,68,68,0.4)"
                                  : "1px solid rgba(249,115,22,0.45)";
                              return (
                                <div
                                  key={susp.id}
                                  className="absolute inset-y-0 z-0"
                                  style={{ right: `${sl}%`, width: `${sw}%`, background: bg, borderLeft: bd, borderRight: bd }}
                                  title={`${suspLabel(susp.type)}: ${susp.startDate} ← ${susp.endDate} (${susp.calendarDays} يوم)`}
                                />
                              );
                            })}

                            {/* Bars */}
                            <div className="absolute inset-0 z-10 flex flex-col justify-center gap-1.5 px-0">
                              {(() => {
                                const hasPlanned = !!(a.plannedStartDate && a.plannedEndDate);
                                const hasAnyStart = !!(a.actualStartDate || a.plannedStartDate);
                                const hasActualSignal = (a.actualProgress > 0 || !!a.actualStartDate) && hasAnyStart;
                                const orphanProgress = a.actualProgress > 0 && !hasAnyStart;

                                // ── Case 1: لا توجد أي تواريخ ولا أي إشارة قابلة للرسم ──
                                if (!hasPlanned && !hasActualSignal && !orphanProgress) {
                                  return (
                                    <div className="relative h-4 flex items-center" title="ينقص هذا البند تواريخ مخططة">
                                      <div
                                        className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-0"
                                        style={{ borderTop: "1.5px dashed rgba(148,163,184,0.6)" }}
                                      />
                                      <span className="absolute right-1 top-1/2 -translate-y-1/2 text-amber-500 bg-background rounded-full p-0.5">
                                        <AlertTriangle className="w-3 h-3" />
                                      </span>
                                    </div>
                                  );
                                }

                                // ── Case 2: نسبة إنجاز بدون أي تواريخ — تنبيه + النسبة ──
                                if (orphanProgress) {
                                  return (
                                    <div
                                      className="relative h-4 flex items-center justify-end pr-2 gap-1.5"
                                      title={`نسبة إنجاز ${a.actualProgress}% بدون تواريخ مسجلة`}
                                    >
                                      <div
                                        className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-0"
                                        style={{ borderTop: "1.5px dashed rgba(148,163,184,0.6)" }}
                                      />
                                      <span className="relative z-10 text-[10px] font-bold text-foreground bg-background px-1.5 rounded border border-amber-300">
                                        {a.actualProgress}%
                                      </span>
                                      <span className="relative z-10 text-amber-500 bg-background rounded-full p-0.5">
                                        <AlertTriangle className="w-3 h-3" />
                                      </span>
                                    </div>
                                  );
                                }

                                return (
                                  <>
                                    {/* Planned bar */}
                                    <div className="relative h-4">
                                      {hasPlanned ? (() => {
                                        const sl = toPct(new Date(a.plannedStartDate!));
                                        const el = toPct(new Date(a.plannedEndDate!));
                                        const w = Math.max(0.5, el - sl);
                                        return (
                                          <div
                                            className="absolute h-full rounded-full bg-blue-400/70"
                                            style={{ right: `${sl}%`, width: `${w}%` }}
                                            title={`مخطط: ${fmtDate(a.plannedStartDate!)} → ${fmtDate(a.plannedEndDate!)}`}
                                          />
                                        );
                                      })() : (
                                        <div
                                          className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-0"
                                          style={{ borderTop: "1.5px dashed rgba(148,163,184,0.5)" }}
                                          title="لا يوجد جدول مخطط لهذا البند"
                                        />
                                      )}
                                    </div>

                                    {/* Actual bar */}
                                    {hasActualSignal && (
                                      <div className="relative h-4">
                                        {(() => {
                                          const ongoing = !a.actualEndDate && a.status !== "completed";
                                          const startIso = a.actualStartDate ?? a.plannedStartDate!;
                                          const startPct = toPct(new Date(startIso));
                                          const startLabel = a.actualStartDate
                                            ? fmtDate(a.actualStartDate)
                                            : `(مخطط) ${fmtDate(a.plannedStartDate!)}`;

                                          // Marker: بدأ النشاط بدون نسبة مسجلة
                                          if (a.actualProgress === 0 && a.actualStartDate) {
                                            return (
                                              <div
                                                className="absolute h-full"
                                                style={{ right: `calc(${startPct}% - 1.5px)`, width: 3 }}
                                                title={`بدأ في ${fmtDate(a.actualStartDate)} — بدون إنجاز مسجَّل بعد`}
                                              >
                                                <div
                                                  className="h-full w-full rounded-sm"
                                                  style={{ backgroundColor: barColor, opacity: 0.85 }}
                                                />
                                              </div>
                                            );
                                          }

                                          // حساب نقطة النهاية
                                          let endPct: number;
                                          let endLabel: string;
                                          if (a.actualEndDate) {
                                            endPct = toPct(new Date(a.actualEndDate));
                                            endLabel = fmtDate(a.actualEndDate);
                                          } else if (ongoing) {
                                            endPct = todayPct;
                                            endLabel = "جارٍ حتى اليوم";
                                          } else if (hasPlanned) {
                                            const ps = toPct(new Date(a.plannedStartDate!));
                                            const pe = toPct(new Date(a.plannedEndDate!));
                                            const plannedW = Math.max(0.5, pe - ps);
                                            endPct = startPct + plannedW * a.actualProgress / 100;
                                            endLabel = "—";
                                          } else {
                                            endPct = startPct;
                                            endLabel = "—";
                                          }

                                          const w = Math.max(0.5, endPct - startPct);
                                          return (
                                            <div
                                              className="absolute h-full rounded-full flex items-center overflow-hidden"
                                              style={{
                                                right: `${startPct}%`,
                                                width: `${w}%`,
                                                backgroundColor: barColor,
                                                ...(ongoing ? { borderLeft: "3px solid white" } : {}),
                                              }}
                                              title={`فعلي: ${startLabel} → ${endLabel} (${a.actualProgress}%)`}
                                            >
                                              {w > 8 && (
                                                <span className="text-[9px] font-bold text-white px-1.5 truncate">
                                                  {a.actualProgress}%
                                                </span>
                                              )}
                                            </div>
                                          );
                                        })()}
                                      </div>
                                    )}
                                  </>
                                );
                              })()}
                            </div>
                          </div>
                        </div>
                      );
                    })}

                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })()}

        {!isContractorBase && effectiveViewMode === "gantt" && (
        <Card className="surface-card surface-card-hover">
          <CardHeader>
            <CardTitle className="text-base">الإنجاز المخطط مقابل الفعلي</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ganttData} margin={{ top: 10, right: 20, left: 0, bottom: 50 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" angle={-40} textAnchor="end" height={60} interval={0} fontSize={11} />
                  <YAxis domain={[0, 100]} tickFormatter={(v: number) => `${v}%`} fontSize={11} />
                  <Tooltip
                    contentStyle={{ textAlign: 'right', direction: 'rtl', fontSize: 12 }}
                    formatter={(v: number) => [`${v}%`]}
                  />
                  <Bar dataKey="المخطط" fill="hsl(var(--muted-foreground))" opacity={0.4} radius={[3, 3, 0, 0]} />
                  <Bar dataKey="الفعلي" fill="hsl(var(--primary))" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        )}

        {effectiveViewMode === "list" && !isContractorBase && (
        <Card className="surface-card surface-card-hover">
          <CardHeader className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">بنود الأعمال</CardTitle>
                <p className="text-xs text-muted-foreground mt-0.5 hidden sm:block">انقر على الحالة أو نسبة الإنجاز لتحديثها مباشرةً</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
            {!isViewer && (
            <Dialog open={isGroupDialogOpen} onOpenChange={setIsGroupDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="gap-1.5 text-xs sm:text-sm">
                  <FolderPlus className="h-4 w-4" /> <span className="hidden sm:inline">مجموعة جديدة</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden" dir="rtl">
                <div className="bg-muted/30 p-6 pb-4 border-b border-border/50">
                  <DialogHeader>
                    <DialogTitle className="text-xl">إضافة مجموعة جديدة</DialogTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      قم بإنشاء مجموعة جديدة لتنظيم بنود الأعمال الخاصة بالمشروع.
                    </p>
                  </DialogHeader>
                </div>
                <div className="p-6 pt-4 space-y-6">
                  <div className="p-5 rounded-2xl border bg-muted/20 shadow-sm space-y-5">
                    <div>
                      <label className="text-sm font-semibold mb-2 block text-foreground/90">اسم المجموعة</label>
                      <Input className="h-11 bg-background" value={newGroupName} onChange={e => setNewGroupName(e.target.value)} placeholder="مثال: الأعمال الخرسانية" />
                    </div>
                    <div>
                      <label className="text-sm font-semibold mb-2 block text-foreground/90">لون المجموعة</label>
                      <div className="flex flex-wrap gap-3">
                        {GROUP_COLORS.map(c => (
                          <button
                            key={c.value}
                            className={`w-9 h-9 rounded-full border-2 transition-all shadow-sm ${newGroupColor === c.value ? "border-foreground scale-110" : "border-transparent hover:scale-105"}`}
                            style={{ backgroundColor: c.value }}
                            onClick={() => setNewGroupColor(c.value)}
                            title={c.label}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 pt-4 border-t sticky bottom-0 bg-background/95 backdrop-blur-xl pb-2 z-10 -mx-2 px-2">
                    <Button variant="outline" className="w-full sm:w-auto" onClick={() => setIsGroupDialogOpen(false)}>إلغاء</Button>
                    <Button
                      className="w-full sm:w-auto shadow-md"
                      disabled={!newGroupName.trim() || createGroup.isPending}
                      onClick={() => createGroup.mutate({ name: newGroupName.trim(), color: newGroupColor })}
                    >
                      {createGroup.isPending ? "جاري الإنشاء..." : "تأكيد وإنشاء"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            )}
            <Button size="sm" variant="outline" className="gap-1.5 text-xs sm:text-sm" onClick={exportActivities} disabled={!activities || activities.length === 0}>
              <Download className="h-4 w-4" /> <span className="hidden xs:inline">تصدير</span> <span className="hidden sm:inline">Excel</span>
            </Button>
            {!isViewer && (
            <Dialog open={isImportOpen} onOpenChange={(open) => {
              setIsImportOpen(open);
              if (!open) setImportFile(null);
            }}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="gap-1.5 text-xs sm:text-sm">
                  <Upload className="h-4 w-4" /> <span className="hidden xs:inline">استيراد</span> <span className="hidden sm:inline">Excel</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[550px] p-0 overflow-hidden" dir="rtl">
                <div className="bg-muted/30 p-6 pb-4 border-b border-border/50">
                  <DialogHeader>
                    <DialogTitle className="text-xl">استيراد بنود من ملف Excel</DialogTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      قم برفع ملف Excel لإضافة عدة بنود أعمال دفعة واحدة.
                    </p>
                  </DialogHeader>
                </div>
                <div className="p-6 pt-4 space-y-6">
                  <div className="rounded-2xl border-2 border-dashed border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors p-8 text-center">
                    <FileSpreadsheet className="h-12 w-12 mx-auto text-primary/60 mb-4" />
                    <p className="text-sm font-medium text-foreground/90 mb-2">
                      اسحب وأفلت ملف Excel هنا، أو انقر للاختيار
                    </p>
                    <input
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                      className="block w-full max-w-xs mx-auto text-sm text-muted-foreground file:me-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90 cursor-pointer transition-all"
                    />
                    {importFile && (
                      <div className="mt-4 p-3 bg-background rounded-xl border border-emerald-500/30 inline-block shadow-sm">
                        <p className="text-sm text-emerald-600 font-semibold flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4" />
                          {importFile.name}
                        </p>
                      </div>
                    )}
                  </div>
                  <div className="bg-muted/20 rounded-2xl border p-5 shadow-sm">
                    <p className="text-sm text-foreground/80 mb-3 leading-relaxed">
                      يجب أن يحتوي الملف على 3 أعمدة رئيسية للعمل بشكل صحيح: <strong className="text-primary">اسم البند</strong>، <strong className="text-primary">تاريخ البداية</strong>، <strong className="text-primary">تاريخ النهاية</strong>.
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      className="gap-2 bg-background w-full sm:w-auto"
                      onClick={downloadTemplate}
                    >
                      <Download className="h-4 w-4" /> تحميل ملف عينة للتأكد من التنسيق
                    </Button>
                  </div>
                  <div className="flex justify-end gap-3 pt-4 border-t sticky bottom-0 bg-background/95 backdrop-blur-xl pb-2 z-10 -mx-2 px-2">
                    <Button variant="outline" className="w-full sm:w-auto" onClick={() => { setIsImportOpen(false); setImportFile(null); }}>
                      إلغاء
                    </Button>
                    <Button onClick={handleImport} disabled={!importFile || isImporting} className="w-full sm:w-auto shadow-md gap-2">
                      {isImporting ? <><Loader2 className="h-4 w-4 animate-spin" /> جاري الاستيراد...</> : <><Upload className="h-4 w-4" /> بدء الاستيراد</>}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            )}
            {!isViewer && (
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) { form.reset(); setEditingId(null); }
            }}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-1.5 text-xs sm:text-sm mr-auto">
                  <Plus className="h-4 w-4" /> إضافة بند
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[700px] p-0 overflow-hidden max-h-[90vh]" dir="rtl">
                <div className="bg-muted/30 p-6 pb-4 border-b border-border/50">
                  <DialogHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-blue-500/10 rounded-xl">
                        {editingId ? <Edit2 className="h-6 w-6 text-blue-600" /> : <Plus className="h-6 w-6 text-blue-600" />}
                      </div>
                      <div>
                        <DialogTitle className="text-xl">{editingId ? "تعديل البند" : "إضافة بند جديد"}</DialogTitle>
                        <p className="text-sm text-muted-foreground mt-1">
                          {editingId ? "قم بتحديث تفاصيل البند وحالته الحالية." : "أدخل تفاصيل ومواعيد البند الجديد لمتابعته في الجدول الزمني."}
                        </p>
                      </div>
                    </div>
                  </DialogHeader>
                </div>
                
                <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 pt-4 space-y-6">
                      
                      <div className="p-5 rounded-2xl border bg-muted/20 shadow-sm space-y-5">
                        <FormField control={form.control} name="name" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">اسم البند</FormLabel>
                            <FormControl><Input className="h-11 bg-background" {...field} placeholder="مثال: أعمال صب القواعد الخرسانية" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 p-5 rounded-2xl border bg-muted/20 shadow-sm">
                        <FormField control={form.control} name="plannedStartDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">بداية مخططة {isNoSchedule && <span className="text-xs text-muted-foreground font-normal">(اختياري)</span>}</FormLabel>
                            <FormControl><Input type="date" className="h-11 bg-background" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="plannedEndDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">نهاية مخططة {isNoSchedule && <span className="text-xs text-muted-foreground font-normal">(اختياري)</span>}</FormLabel>
                            <FormControl><Input type="date" className="h-11 bg-background" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        
                        <div className="sm:col-span-2 h-px bg-border/50 my-1" />

                        <FormField control={form.control} name="actualStartDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">بداية فعلية</FormLabel>
                            <FormControl><Input type="date" className="h-11 bg-background" {...field} value={field.value ?? ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="actualEndDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">نهاية فعلية</FormLabel>
                            <FormControl><Input type="date" className="h-11 bg-background" {...field} value={field.value ?? ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 p-5 rounded-2xl border bg-muted/20 shadow-sm">
                        <FormField control={form.control} name="actualProgress" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">الإنجاز الفعلي (%)</FormLabel>
                            <FormControl><Input type="number" className="h-11 bg-background font-mono" min={0} max={100} {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="weight" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90 flex items-center justify-between">الوزن النسبي <span className="text-[10px] font-normal text-muted-foreground bg-muted px-1.5 py-0.5 rounded">الافتراضي 1</span></FormLabel>
                            <FormControl><Input type="number" className="h-11 bg-background font-mono" min={0} step="0.1" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="sortOrder" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground/90">الترتيب</FormLabel>
                            <FormControl><Input type="number" className="h-11 bg-background font-mono" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="status" render={({ field }) => (
                          <FormItem className="sm:col-span-2 lg:col-span-3 mt-2">
                            <FormLabel className="text-foreground/90">الحالة الحالية</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl><SelectTrigger className="h-11 bg-background" dir="rtl"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent dir="rtl">
                                {STATUS_OPTIONS.map(o => (
                                  <SelectItem key={o.value} value={o.value}>
                                    <div className="flex items-center gap-2">
                                      <o.icon className={`h-4 w-4 ${o.cls}`} />
                                      {o.label}
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>

                      <div className="flex justify-end gap-3 pt-6 border-t mt-8 sticky bottom-0 bg-background/95 backdrop-blur-xl pb-2 z-10 -mx-2 px-2">
                        <Button type="button" variant="outline" className="w-full sm:w-auto" onClick={() => setIsDialogOpen(false)}>إلغاء والتراجع</Button>
                        <Button type="submit" className="w-full sm:w-auto shadow-md" disabled={form.formState.isSubmitting}>
                          {form.formState.isSubmitting ? "جاري الحفظ..." : editingId ? "حفظ تعديلات البند" : "تأكيد إضافة البند"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </div>
              </DialogContent>
            </Dialog>
            )}
            </div>
          </CardHeader>

          {/* Desktop Table */}
          <CardContent className="p-0 overflow-x-auto hidden md:block">
            {(() => {
              const allActs = activityRows;
              const groupMap = new Map<number | "ungrouped", (Activity & { groupId?: number | null })[]>();
              const sortedGroups = [...groups].sort((a, b) => a.sortOrder - b.sortOrder);

              for (const g of sortedGroups) groupMap.set(g.id, []);
              groupMap.set("ungrouped", []);

              for (const a of allActs) {
                const gid = (a as any).groupId ?? "ungrouped";
                if (!groupMap.has(gid)) groupMap.set("ungrouped", [...(groupMap.get("ungrouped") ?? []), a]);
                else groupMap.get(gid)!.push(a);
              }
              const visibleGroups = sortedGroups.filter((group) => (groupMap.get(group.id) ?? []).length > 0);

              const renderActivityRow = (a: Activity) => {
                const isBusy = updatingId === a.id;
                const planned = calcPlannedProgress(a);
                const deviation = a.actualProgress - planned;
                const delayInfo = calcActivityDelay(a);
                const editable = canEditActivity(a);
                return (
                  <SortableActivityRow key={a.id} id={a.id}>
                    <TableCell className="font-medium max-w-[200px]">
                      <div className="flex items-center gap-1">
                        {!isViewer && <DragHandle />}
                        <span className="block truncate" title={a.name}>{a.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="w-[190px]">
                      <div className="flex flex-col gap-0.5 font-mono text-xs tabular-nums">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-muted-foreground w-8 shrink-0">بداية</span>
                          <span className="text-foreground">{fmtDate(a.plannedStartDate)}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-muted-foreground w-8 shrink-0">نهاية</span>
                          <span className="text-foreground">{fmtDate(a.plannedEndDate)}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <DelayBadge info={delayInfo} />
                    </TableCell>
                    <TableCell className="w-[160px]">
                      <div className="space-y-1">
                        <ProgressBar value={planned} color="hsl(var(--muted-foreground)/0.4)" />
                        <ProgressBar value={a.actualProgress} color="hsl(var(--primary))" />
                        <div className={`text-xs flex items-center gap-0.5 justify-end ${deviation < 0 ? 'text-destructive' : deviation > 0 ? 'text-emerald-600' : 'text-muted-foreground'}`}>
                          {deviation < 0 ? <TrendingDown className="h-3 w-3" /> : deviation > 0 ? <TrendingUp className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
                          {deviation > 0 ? '+' : ''}{deviation}%
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {editable ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-accent transition-colors text-sm">
                              <StatusBadge status={a.status} />
                              <ChevronDown className="h-3 w-3 text-muted-foreground" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="start">
                            <DropdownMenuLabel className="text-xs text-muted-foreground">تغيير الحالة</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {STATUS_OPTIONS.map(opt => {
                              const Icon = opt.icon;
                              return (
                                <DropdownMenuItem
                                  key={opt.value}
                                  className={`gap-2 ${opt.cls} ${a.status === opt.value ? 'font-bold bg-accent' : ''}`}
                                  onClick={() => quickUpdateStatus(a, opt.value)}
                                >
                                  <Icon className="h-4 w-4" />
                                  {opt.label}
                                  {a.status === opt.value && <span className="mr-auto text-xs">✓</span>}
                                </DropdownMenuItem>
                              );
                            })}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : (
                        <StatusBadge status={a.status} />
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        {editable ? (
                          <>
                            <Button variant="outline" size="icon" className="h-7 w-7" title="تخفيض الإنجاز 5%" onClick={() => quickIncrement(a, -5)} disabled={a.actualProgress === 0}>
                              <span className="text-xs font-bold text-muted-foreground">-5</span>
                            </Button>
                            <Button variant="outline" size="icon" className="h-7 w-7" title="رفع الإنجاز 5%" onClick={() => quickIncrement(a, 5)} disabled={a.actualProgress === 100}>
                              <span className="text-xs font-bold text-primary">+5</span>
                            </Button>
                            {groups.length > 0 && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-7 w-7">
                                    <FolderPlus className="h-3.5 w-3.5 text-muted-foreground" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="start">
                                  <DropdownMenuLabel className="text-xs text-muted-foreground">نقل إلى مجموعة</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => assignToGroup(a.id, null)}>
                                    <span className="text-muted-foreground">بدون مجموعة</span>
                                  </DropdownMenuItem>
                                  {groups.map(g => (
                                    <DropdownMenuItem key={g.id} onClick={() => assignToGroup(a.id, g.id)}>
                                      <span className="inline-block w-2.5 h-2.5 rounded-full shrink-0 ml-2" style={{ backgroundColor: g.color }} />
                                      {g.name}
                                    </DropdownMenuItem>
                                  ))}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(a)}>
                              <Edit2 className="h-3.5 w-3.5 text-muted-foreground" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setDeletingId(a.id)}>
                              <Trash2 className="h-3.5 w-3.5 text-destructive" />
                            </Button>
                          </>
                        ) : (
                          <span className="text-xs text-muted-foreground">عرض فقط</span>
                        )}
                      </div>
                    </TableCell>
                  </SortableActivityRow>
                );
              };

              return (
                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                  <Table className="min-w-[720px]">
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right w-[220px]">البند</TableHead>
                        <TableHead className="text-right w-[190px]">الفترة المخططة</TableHead>
                        <TableHead className="text-center w-[140px]">التأخر / التقدم</TableHead>
                        <TableHead className="text-center w-[160px]">الإنجاز (مخطط/فعلي)</TableHead>
                        <TableHead className="text-right w-[130px]">الحالة</TableHead>
                        <TableHead className="text-center w-[110px]">إجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoading ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                            <div className="flex flex-col items-center gap-2">
                              <Loader2 className="h-6 w-6 animate-spin text-primary/60" />
                              <span className="text-sm">جاري تحميل بنود الأعمال...</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : allActs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">{hasActiveFilters ? "لا توجد نتائج مطابقة للفلاتر الحالية" : "لا يوجد بنود — أضف أول بند"}</TableCell>
                        </TableRow>
                      ) : groups.length === 0 ? (
                        <SortableContext items={allActs.map(a => a.id)} strategy={verticalListSortingStrategy}>
                          {allActs.map(renderActivityRow)}
                        </SortableContext>
                      ) : (
                        <SortableContext items={[...visibleGroups.map(g => `group-${g.id}`), ...allActs.map(a => a.id)]} strategy={verticalListSortingStrategy}>
                          {visibleGroups.map(g => {
                            const groupActs = groupMap.get(g.id) ?? [];
                            const isCollapsed = collapsedGroups.has(g.id);
                            const groupProgress = (() => {
                              if (groupActs.length === 0) return 0;
                              let s = 0, w = 0;
                              for (const a of groupActs) {
                                const ww = (a as any).weight && (a as any).weight > 0 ? (a as any).weight : 1;
                                s += (a.actualProgress ?? 0) * ww;
                                w += ww;
                              }
                              return w > 0 ? Math.round((s / w) * 10) / 10 : 0;
                            })();
                            return (
                              <React.Fragment key={g.id}>
                                <SortableGroupRow id={`group-${g.id}`}>
                                  <TableCell colSpan={4} onClick={() => toggleGroupCollapse(g.id)}>
                                    <div className="flex items-center gap-2">
                                      {!isViewer && <DragHandle />}
                                      {isCollapsed ? <ChevronLeft className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                                      <span className="inline-block w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: g.color }} />
                                      <span className="font-semibold text-sm">{g.name}</span>
                                      <span className="text-xs text-muted-foreground">({groupActs.length} بند)</span>
                                      <span className="text-xs text-muted-foreground mr-2">{groupProgress}%</span>
                                    </div>
                                  </TableCell>
                                  <TableCell colSpan={2}>
                                    <div className="flex items-center justify-end gap-1">
                                      <div className="flex-1 max-w-[80px]">
                                        <ProgressBar value={groupProgress} color={g.color} />
                                      </div>
                                      {!isViewer && (
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6"
                                        onClick={(e) => { e.stopPropagation(); deleteGroup.mutate(g.id); }}
                                      >
                                        <X className="h-3 w-3 text-muted-foreground" />
                                      </Button>
                                      )}
                                    </div>
                                  </TableCell>
                                </SortableGroupRow>
                                {!isCollapsed && groupActs.map(renderActivityRow)}
                              </React.Fragment>
                            );
                          })}
                          {(() => {
                            const ungrouped = groupMap.get("ungrouped") ?? [];
                            if (ungrouped.length === 0) return null;
                            const isCollapsed = collapsedGroups.has("ungrouped");
                            return (
                              <>
                                {groups.length > 0 && (
                                  <TableRow className="bg-muted/30 hover:bg-muted/50 cursor-pointer" onClick={() => toggleGroupCollapse("ungrouped")}>
                                    <TableCell colSpan={6}>
                                      <div className="flex items-center gap-2">
                                        {isCollapsed ? <ChevronLeft className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                                        <span className="font-semibold text-sm text-muted-foreground">بدون مجموعة</span>
                                        <span className="text-xs text-muted-foreground">({ungrouped.length} بند)</span>
                                      </div>
                                    </TableCell>
                                  </TableRow>
                                )}
                                {!isCollapsed && ungrouped.map(renderActivityRow)}
                              </>
                            );
                          })()}
                        </SortableContext>
                      )}
                    </TableBody>
                  </Table>
                </DndContext>
              );
            })()}
          </CardContent>

          {/* Mobile Card View */}
          <CardContent className="md:hidden space-y-3 px-3">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12 gap-2">
                <Loader2 className="h-6 w-6 animate-spin text-primary/60" />
                <span className="text-sm text-muted-foreground">جاري تحميل بنود الأعمال...</span>
              </div>
            ) : activityRows.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">{hasActiveFilters ? "لا توجد نتائج مطابقة للفلاتر الحالية" : "لا يوجد بنود — أضف أول بند"}</div>
            ) : (() => {
              const allActs = activityRows;
              const sortedGroups = [...groups].sort((a, b) => a.sortOrder - b.sortOrder);
              const groupMap = new Map<number | "ungrouped", Activity[]>();
              for (const g of sortedGroups) groupMap.set(g.id, []);
              groupMap.set("ungrouped", []);
              for (const a of allActs) {
                const gid = (a as any).groupId ?? "ungrouped";
                if (!groupMap.has(gid)) groupMap.get("ungrouped")!.push(a);
                else groupMap.get(gid)!.push(a);
              }
              const visibleGroups = sortedGroups.filter((group) => (groupMap.get(group.id) ?? []).length > 0);

              const renderMobileCard = (a: Activity) => {
                const isBusy = updatingId === a.id;
                const planned = calcPlannedProgress(a);
                const deviation = a.actualProgress - planned;
                const delayInfo = calcActivityDelay(a);
                const editable = canEditActivity(a);
                return (
                  <div key={a.id} className={`rounded-lg border p-3 space-y-2.5 ${isBusy ? "opacity-60 pointer-events-none" : ""}`}>
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-sm font-medium leading-tight flex-1">{a.name}</span>
                      <StatusBadge status={a.status} />
                    </div>
                    <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                      <span className="tabular-nums">{fmtDate(a.plannedStartDate)} → {fmtDate(a.plannedEndDate)}</span>
                      <DelayBadge info={delayInfo} />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">مخطط {planned}%</span>
                        <span className="text-muted-foreground">فعلي {a.actualProgress}%</span>
                        <span className={deviation < 0 ? 'text-destructive font-medium' : deviation > 0 ? 'text-emerald-600 font-medium' : 'text-muted-foreground'}>
                          {deviation > 0 ? '+' : ''}{deviation}%
                        </span>
                      </div>
                      <ProgressBar value={a.actualProgress} color="hsl(var(--primary))" />
                    </div>
                    {editable ? (
                      <div className="flex items-center gap-1 pt-1 border-t">
                        <div className="flex items-center gap-1 mr-auto">
                          <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => quickIncrement(a, -5)} disabled={a.actualProgress === 0}>
                            <span className="text-xs font-bold text-muted-foreground">-5</span>
                          </Button>
                          <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => quickIncrement(a, 5)} disabled={a.actualProgress === 100}>
                            <span className="text-xs font-bold text-primary">+5</span>
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(a)}>
                            <Edit2 className="h-3.5 w-3.5 text-muted-foreground" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setDeletingId(a.id)}>
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="pt-1 border-t">
                        <span className="text-xs text-muted-foreground">عرض فقط</span>
                      </div>
                    )}
                  </div>
                );
              };

              if (groups.length === 0) return allActs.map(renderMobileCard);

              return (
                <>
                  {visibleGroups.map((g, gi) => {
                    const groupActs = groupMap.get(g.id) ?? [];
                    const isCollapsed = collapsedGroups.has(g.id);
                    const groupProgress = (() => {
                      if (groupActs.length === 0) return 0;
                      let s = 0, w = 0;
                      for (const a of groupActs) {
                        const ww = (a as any).weight && (a as any).weight > 0 ? (a as any).weight : 1;
                        s += (a.actualProgress ?? 0) * ww;
                        w += ww;
                      }
                      return w > 0 ? Math.round((s / w) * 10) / 10 : 0;
                    })();
                    const moveGroup = (dir: -1 | 1) => {
                      const newIdx = gi + dir;
                      if (newIdx < 0 || newIdx >= sortedGroups.length) return;
                      const reordered = arrayMove([...sortedGroups], gi, newIdx);
                      reorderGroupsMutation.mutate(reordered.map(x => x.id));
                    };
                    return (
                      <div key={g.id}>
                        <div
                          className="flex items-center gap-1.5 rounded-lg p-2.5 mb-2 transition-colors"
                          style={{ backgroundColor: `${g.color}15`, borderRight: `3px solid ${g.color}` }}
                        >
                          <div className="flex flex-col gap-0.5">
                            <button
                              className="p-0.5 rounded hover:bg-black/10 disabled:opacity-30"
                              disabled={gi === 0}
                              onClick={() => moveGroup(-1)}
                            >
                              <ChevronDown className="h-3 w-3 rotate-180" />
                            </button>
                            <button
                              className="p-0.5 rounded hover:bg-black/10 disabled:opacity-30"
                              disabled={gi === sortedGroups.length - 1}
                              onClick={() => moveGroup(1)}
                            >
                              <ChevronDown className="h-3 w-3" />
                            </button>
                          </div>
                          <button
                            className="flex items-center gap-2 flex-1 min-w-0"
                            onClick={() => toggleGroupCollapse(g.id)}
                          >
                            {isCollapsed ? <ChevronLeft className="h-4 w-4 shrink-0" /> : <ChevronDown className="h-4 w-4 shrink-0" />}
                            <span className="inline-block w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: g.color }} />
                            <span className="font-semibold text-sm flex-1 text-right truncate">{g.name}</span>
                            <span className="text-xs text-muted-foreground shrink-0">{groupActs.length} بند</span>
                            <span className="text-xs font-medium shrink-0">{groupProgress}%</span>
                          </button>
                        </div>
                        {!isCollapsed && (
                          <div className="space-y-2 mb-3">
                            {groupActs.map(renderMobileCard)}
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {(() => {
                    const ungrouped = groupMap.get("ungrouped") ?? [];
                    if (ungrouped.length === 0) return null;
                    const isCollapsed = collapsedGroups.has("ungrouped");
                    return (
                      <div>
                        <button
                          className="w-full flex items-center gap-2 rounded-lg p-2.5 mb-2 bg-muted/30"
                          onClick={() => toggleGroupCollapse("ungrouped")}
                        >
                          {isCollapsed ? <ChevronLeft className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          <span className="font-semibold text-sm flex-1 text-right text-muted-foreground">بدون مجموعة</span>
                          <span className="text-xs text-muted-foreground">{ungrouped.length} بند</span>
                        </button>
                        {!isCollapsed && (
                          <div className="space-y-2 mb-3">
                            {ungrouped.map(renderMobileCard)}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </>
              );
            })()}
          </CardContent>
        </Card>
        )}
      </div>

      {!isContractorBase && (
      <AlertDialog open={!!deletingId} onOpenChange={(open) => { if (!open) setDeletingId(null); }}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>هل أنت متأكد من حذف هذا البند؟ لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      )}
    </div>
  );
}
